# Databases-Project-23-24

This is an undergraduate SQL/java project from the Computer Engineering and Informatics Department of the University of Patras. It is a database written is SQL for an employee evaluation system along with a GUI written in java. The /ProjectDB directory contains the GUI part and the /SQL-scripts directory contains 4 SQL scripts for the database, initialization with data, stored procedures and triggers. 

Note: The running of the scripts should be done in the order the files are arranged in the directory.
